# 📦 Instrucciones de instalación — Intranet PWA

## Archivos entregados

| Archivo | Dónde va | Para qué |
|---|---|---|
| `App.js` | `src/App.js` | Reemplaza tu App.js actual |
| `manifest.json` | `public/manifest.json` | Reemplaza el existente |
| `service-worker.js` | `public/service-worker.js` | Archivo nuevo |

---

## Paso 1 — Reemplazar archivos

Copiá los 3 archivos en las rutas indicadas del proyecto.

---

## Paso 2 — Verificar index.html

Abrí `public/index.html` y asegurate de que tenga estas líneas en el `<head>`:

```html
<link rel="manifest" href="%PUBLIC_URL%/manifest.json" />
<meta name="theme-color" content="#1a1a2e" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-status-bar-style" content="default" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
```

---

## Paso 3 — Deploy y uso

1. Corré `npm run build`
2. Subí la carpeta `build/` a tu hosting (Firebase Hosting, Vercel, Netlify, etc.)
3. Abrí la URL desde el celular en Chrome (Android) o Safari (iOS)
4. **Android**: aparece el banner "Agregar a la pantalla de inicio" automáticamente
5. **iOS**: tocá el botón Compartir → "Agregar a pantalla de inicio"

---

## ¿Qué cambió en el App.js?

### 🌙 Modo oscuro
- Activado por defecto si el sistema lo tiene configurado
- Botón ☀️/🌙 en el header para cambiar
- Preferencia guardada en localStorage

### 📱 UI mobile-first
- **Inputs táctiles grandes** (padding 14px, font 16px — evita el zoom automático de iOS)
- **Selector numérico** con `type="tel" inputMode="numeric"` — abre el teclado numérico directamente
- **Barra de navegación inferior** — el menú está abajo, donde llegan los pulgares
- **Grilla de 2 columnas** para los botones de acción
- **Tarjetas colapsables** por negocio — solo ves lo que querés

### ✏️ Edición de meses anteriores
- Nueva sección **"Editar"** en la barra inferior (ícono ✏️)
- Solo disponible para rol **admin**
- **Buscador por mes y negocio** — filtrás entre todos los registros históricos
- Los resultados muestran negocio, fecha y total; con botones Editar y Eliminar
- Al editar, carga el formulario pre-completado en la sección Carga
- Se puede acceder también desde el botón ✏️ de cualquier fila del mes actual

### 🔒 Seguridad
- Se corrigió la credencial hardcodeada: la contraseña está en el objeto `USUARIOS` al inicio del archivo (línea ~30). **Cambiala** por la que uses.
- Sistema preparado para múltiples usuarios con roles (admin / viewer)

---

## Cambio de contraseña

En `App.js`, línea ~30:

```js
const USUARIOS = {
  admin: { password: "TU_CONTRASEÑA_NUEVA", rol: "admin" },
};
```

⚠️ Recordá: esta contraseña sigue estando en el código del frontend (bundle JS). Para seguridad real en producción, usá Firebase Authentication.
